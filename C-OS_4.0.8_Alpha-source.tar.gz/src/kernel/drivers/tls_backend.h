/**
 * tls_backend.h - TLS backend abstraction for HTTPS support
 *
 * This OS source tree is now wired for HTTPS-capable browser integration.
 * A concrete TLS implementation (for example BearSSL or mbedTLS) should
 * provide these functions on top of the socket layer.
 */

#ifndef TLS_BACKEND_H
#define TLS_BACKEND_H

#include "types.h"

typedef struct tls_session tls_session_t;

int tls_backend_available(void);
tls_session_t* tls_connect(const char* host, uint64_t port);
int tls_send(tls_session_t* session, const char* data, size_t len);
int tls_recv(tls_session_t* session, char* buffer, size_t max_len);
void tls_close(tls_session_t* session);

#endif /* TLS_BACKEND_H */
