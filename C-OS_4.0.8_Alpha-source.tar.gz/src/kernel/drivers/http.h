/**
 * http.h - Simple HTTP Client
 */

#ifndef HTTP_H
#define HTTP_H

#include "types.h"
#include "net.h"
#include "tls_backend.h"

#define HTTP_PORT       80
#define HTTPS_PORT      443

#define HTTP_MAX_URL    2048
#define HTTP_MAX_HOST   256
#define HTTP_MAX_PATH   1024
/* Real HTML responses frequently carry several KiB of security and cache
 * headers before the first article text.  Keep enough wire data to preserve
 * meaningful page content for the NetSurf renderer. */
/* Google and Wikimedia frequently exceed 64KiB once headers, consent state,
 * structured data and page markup are included.  The client instance is
 * heap-allocated, so preserve the complete response for NetSurf conversion. */
#define HTTP_MAX_RESP   (512 * 1024)

#define HTTP_OK         200
#define HTTP_FOUND      302
#define HTTP_NOT_FOUND  404

typedef enum {
    HTTP_SCHEME_HTTP = 0,
    HTTP_SCHEME_HTTPS = 1,
} http_scheme_t;

typedef struct {
    socket_t* socket;
    tls_session_t* tls_session;
    ip_addr_t server_ip;
    uint64_t port;
    http_scheme_t scheme;
    
    char host[HTTP_MAX_HOST];
    char path[HTTP_MAX_PATH];
    
    int status_code;
    char response[HTTP_MAX_RESP];
    uint64_t response_len;
    
    int connected;
    /* Set only after a framed HTTP response confirms that the server did not
     * request Connection: close.  Redirects on the same origin may reuse this
     * transport and avoid a second DNS/TCP/TLS handshake. */
    int keep_alive;
} http_client_t;

http_client_t* http_create(void);
void http_destroy(http_client_t* http);

/* URL parsing */
int http_parse_url(const char* url, char* host, char* path, uint64_t* port);

/* HTTP methods */
int http_get(http_client_t* http, const char* url);
int http_post(http_client_t* http, const char* url, const char* data);

/* Response handling */
int http_status_code(http_client_t* http);
const char* http_response_body(http_client_t* http);
uint64_t http_response_length(http_client_t* http);
const char* http_get_header(http_client_t* http, const char* name);

/* Return the final URL after the client's internally followed redirect chain.
 * The caller supplies storage; no transport or allocation occurs here. */
int http_get_effective_url(const http_client_t* http, char* out, size_t out_sz);

/* Accept a Set-Cookie value received by an upper-layer fetcher.  The
 * process-wide jar is shared by short-lived HTTP client instances, while
 * the explicit client argument preserves the origin context when worker
 * transports overlap. */
void http_store_cookie_header_for(const http_client_t* http, const char* set_cookie);
/* Compatibility entry point. It has no origin context and intentionally
 * does not persist a cookie; callers must use the explicit form above. */
void http_store_cookie_header(const char* set_cookie);

/* Simple API for fetching web pages */
int http_fetch(const char* url, char* buffer, size_t max_len);

#endif /* HTTP_H */
