/**
 * dns.c - DNS Client Implementation
 */

#include "dns.h"
#include "net.h"
#include "udp.h"
#include "memory.h"
#include "string.h"
#include "serial.h"
#include "timer.h"
#include "task.h"

/* Byte order conversion functions */
static uint16_t htons(uint16_t n) {
    return ((n & 0xFF) << 8) | ((n >> 8) & 0xFF);
}
static uint16_t ntohs(uint16_t n) {
    return htons(n);
}
static uint32_t htonl(uint32_t n) {
    return ((n & 0xFF) << 24) |
           ((n & 0xFF00) << 8) |
           ((n >> 8) & 0xFF00) |
           ((n >> 24) & 0xFF);
}
static uint32_t ntohl(uint32_t n) {
    return htonl(n);
}

static dns_cache_entry_t dns_cache[DNS_CACHE_SIZE];
static uint16_t dns_next_id = 0x1234;
static ip_addr_t dns_server;
static char dns_pending_hostname[DNS_MAX_NAME_LEN];
#define DNS_NEGATIVE_TTL_TICKS 30000u

static void dns_copy_name(char* dst, size_t dst_sz, const char* src);

static bool dns_cache_entry_live(dns_cache_entry_t *entry, uint32_t now) {
    if (!entry || !entry->valid) return false;
    if (entry->expires != 0 && now >= entry->expires) {
        entry->valid = 0;
        entry->negative = 0;
        return false;
    }
    return true;
}

static void dns_cache_store_negative(const char *name) {
    if (!name || !name[0]) return;
    uint32_t now = (uint32_t)get_timer_ticks();
    int slot = -1;
    uint32_t oldest = 0;
    for (int i = 0; i < DNS_CACHE_SIZE; ++i) {
        if (dns_cache[i].valid && strcmp(dns_cache[i].name, name) == 0) {
            slot = i;
            break;
        }
        if (!dns_cache_entry_live(&dns_cache[i], now)) {
            slot = i;
            break;
        }
        if (slot < 0 || dns_cache[i].timestamp < oldest) {
            slot = i;
            oldest = dns_cache[i].timestamp;
        }
    }
    if (slot < 0) return;
    dns_copy_name(dns_cache[slot].name, sizeof(dns_cache[slot].name), name);
    memset(&dns_cache[slot].ip, 0, sizeof(dns_cache[slot].ip));
    dns_cache[slot].ttl = DNS_NEGATIVE_TTL_TICKS;
    dns_cache[slot].expires = now + DNS_NEGATIVE_TTL_TICKS;
    dns_cache[slot].timestamp = now;
    dns_cache[slot].negative = 1;
    dns_cache[slot].valid = 1;
}

static void dns_copy_name(char* dst, size_t dst_sz, const char* src) {
    if (!dst || dst_sz == 0) return;
    if (!src) { dst[0] = '\0'; return; }
    strncpy(dst, src, dst_sz - 1);
    dst[dst_sz - 1] = '\0';
}

static const uint8_t* dns_skip_name(const uint8_t* ptr, const uint8_t* end) {
    int jumps = 0;
    while (ptr && ptr < end) {
        uint8_t len = *ptr;
        if (len == 0) return ptr + 1;
        if ((len & 0xC0u) == 0xC0u) {
            if (ptr + 2 > end) return NULL;
            return ptr + 2;
        }
        if (len > 63u) return NULL;
        ptr++;
        if (ptr + len > end) return NULL;
        ptr += len;
        if (++jumps > 128) return NULL;
    }
    return NULL;
}

void dns_set_server(const ip_addr_t* server) {
    if (!server || (server->addr[0] == 0 && server->addr[1] == 0 &&
                    server->addr[2] == 0 && server->addr[3] == 0)) {
        return;
    }
    dns_server = *server;
    /* Queries already in flight are not retained by this synchronous
     * client, so invalidating the cache is sufficient and deterministic. */
    memset(dns_cache, 0, sizeof(dns_cache));
    serial_puts("[DNS] Server updated from DHCP: ");
    for (int i = 0; i < 4; i++) {
        serial_putdec(dns_server.addr[i]);
        if (i < 3) serial_puts(".");
    }
    serial_puts("\n");
}

void dns_init(void) {
    memset(dns_cache, 0, sizeof(dns_cache));
    memset(dns_pending_hostname, 0, sizeof(dns_pending_hostname));

    /* Use DHCP provided DNS or fallback */
    extern ip_addr_t dhcp_get_dns(void);
    dns_server = dhcp_get_dns();
    
    /* Fallback to Google DNS (8.8.8.8) */
    if (dns_server.addr[0] == 0) {
        dns_server = ip_make_addr(8, 8, 8, 8);
    }
    
    serial_puts("[DNS] DNS client initialized, server: ");
    for (int i = 0; i < 4; i++) {
        serial_putdec(dns_server.addr[i]);
        if (i < 3) serial_puts(".");
    }
    serial_puts("\n");
}

static int dns_encode_name(uint8_t* buf, size_t buf_sz, const char* name) {
    /* buf_sz bounds the caller's actual buffer (e.g. a fixed-size stack
     * packet). Every write below must be checked against it -- a
     * user-supplied hostname (typed into the browser URL bar, etc.) is
     * untrusted length and previously had no bound here at all, allowing
     * a stack buffer overflow via dns_query()'s 512-byte packet[]. */
    size_t len = 0;
    const char* pos = name;
    
    while (*pos) {
        /* Find label length */
        const char* dot = strchr(pos, '.');
        int label_len;
        if (dot) {
            label_len = dot - pos;
        } else {
            label_len = strlen(pos);
        }
        
        if (label_len > 63) return -1;
        if (label_len < 0) return -1;
        
        /* Need room for: 1 length byte + label_len bytes + final 1-byte
         * terminator that gets written after the loop. */
        if (len + 1 + (size_t)label_len + 1 > buf_sz) return -1;
        
        *buf++ = (uint8_t)label_len;
        memcpy(buf, pos, (size_t)label_len);
        buf += label_len;
        len += (size_t)label_len + 1;
        
        if (dot) {
            pos = dot + 1;
        } else {
            break;
        }
    }
    
    if (len + 1 > buf_sz) return -1;
    *buf++ = 0;  // Terminator
    len++;
    
    return (int)len;
}

int dns_query(const char* hostname, uint16_t type) {
    if (!hostname || !hostname[0]) return -1;
    uint8_t packet[DNS_MAX_PACKET];
    
    /* Build header */
    dns_header_t* hdr = (dns_header_t*)packet;
    hdr->id = htons(dns_next_id++);
    hdr->flags = htons(DNS_FLAG_RD);
    hdr->questions = htons(1);
    hdr->answers = htons(0);
    hdr->authority = htons(0);
    hdr->additional = htons(0);
    
    int offset = sizeof(dns_header_t);
    
    /* Encode name */
    if (offset + 4 > DNS_MAX_PACKET) return -1;
    int name_len = dns_encode_name(packet + offset, DNS_MAX_PACKET - offset - 4, hostname);
    if (name_len < 0) return -1;
    offset += name_len;
    
    /* Query type */
    *(uint16_t*)(packet + offset) = htons(type);
    offset += 2;
    
    /* Query class (IN) */
    *(uint16_t*)(packet + offset) = htons(DNS_CLASS_IN);
    offset += 2;
    
    dns_copy_name(dns_pending_hostname, sizeof(dns_pending_hostname), hostname);

    /* Send query */
    udp_send(&dns_server, 49152 + (dns_next_id % 1000), DNS_PORT, packet, offset);

    return ntohs(hdr->id);
}

void dns_handle_response(void* data, size_t len) {
    if (!data || len < sizeof(dns_header_t)) return;

    const uint8_t* start = (const uint8_t*)data;
    const uint8_t* end = start + len;
    const dns_header_t* hdr = (const dns_header_t*)data;
    uint16_t flags = ntohs(hdr->flags);
    uint16_t rcode = flags & 0x0F;

    if (rcode != DNS_RCODE_NOERROR) {
        serial_puts("[DNS] Error response: ");
        serial_putdec(rcode);
        serial_puts("\n");
        /* NXDOMAIN is a completed answer, not a transport timeout. Keep a
         * short negative cache entry so browser subresources do not issue the
         * same failing query hundreds of times while a page is converted. */
        if (rcode == DNS_RCODE_NXDOMAIN) {
            dns_cache_store_negative(dns_pending_hostname);
        }
        return;
    }

    uint16_t answers = ntohs(hdr->answers);
    if (answers == 0) return;

    const uint8_t* ptr = start + sizeof(dns_header_t);
    uint16_t questions = ntohs(hdr->questions);

    for (uint16_t q = 0; q < questions; q++) {
        const uint8_t* next = dns_skip_name(ptr, end);
        if (!next || next + 4 > end) return;
        ptr = next + 4;
    }

    /* A modern hostname commonly returns one or more CNAME records before
       its A record (Wikipedia does).  The old code examined only the first
       answer, silently discarding a perfectly valid A record later in the
       response and making DNS appear to time out. */
    for (uint16_t answer = 0; answer < answers; ++answer) {
        const uint8_t* next = dns_skip_name(ptr, end);
        if (!next || next + 10 > end) return;
        ptr = next;

        uint16_t type = ntohs(*(const uint16_t*)ptr); ptr += 2;
        uint16_t class = ntohs(*(const uint16_t*)ptr); ptr += 2;
        uint32_t ttl = ntohl(*(const uint32_t*)ptr); ptr += 4;
        uint16_t rdlen = ntohs(*(const uint16_t*)ptr); ptr += 2;
        if (ptr + rdlen > end) return;

        if (type == DNS_TYPE_A && class == DNS_CLASS_IN && rdlen == 4) {
            ip_addr_t ip;
            memcpy(ip.addr, ptr, 4);

            serial_puts("[DNS] Resolved to: ");
            for (int i = 0; i < 4; i++) {
                serial_putdec(ip.addr[i]);
                if (i < 3) serial_puts(".");
            }
            serial_puts("\n");

            /* DNS_CACHE_SIZE is intentionally bounded for freestanding memory
             * use.  A browser visits more than 16 origins quickly (documents,
             * CDNs, icons), so retaining entries only while an unused slot
             * exists caused every later hostname to resolve repeatedly without
             * ever becoming visible to dns_resolve().  Replace an expired or
             * least-recently-stored entry once the compact cache is full. */
            uint32_t now = (uint32_t)get_timer_ticks();
            int slot = -1;
            uint32_t oldest = 0;
            for (int i = 0; i < DNS_CACHE_SIZE; i++) {
                if (dns_cache[i].valid &&
                    strcmp(dns_cache[i].name,
                           dns_pending_hostname[0] ? dns_pending_hostname : "resolved") == 0) {
                    slot = i;
                    break;
                }
                if (!dns_cache[i].valid) {
                    slot = i;
                    break;
                }
                if (dns_cache[i].expires != 0 && now >= dns_cache[i].expires) {
                    slot = i;
                    break;
                }
                if (slot < 0 || dns_cache[i].timestamp < oldest) {
                    slot = i;
                    oldest = dns_cache[i].timestamp;
                }
            }
            if (slot >= 0) {
                dns_copy_name(dns_cache[slot].name, sizeof(dns_cache[slot].name),
                              dns_pending_hostname[0] ? dns_pending_hostname : "resolved");
                dns_cache[slot].ip = ip;
                dns_cache[slot].ttl = ttl;
                dns_cache[slot].expires = ttl ? (now + ttl) : 0;
                dns_cache[slot].timestamp = now;
                dns_cache[slot].negative = 0;
                dns_cache[slot].valid = 1;
            }
            return;
        }

        ptr += rdlen;
    }
}

int dns_resolve(const char* hostname, ip_addr_t* result) {
    if (!hostname || !result) return -1;
    /* Check positive and negative cache first. Expired entries are removed
     * lazily, which keeps the fixed-size cache bounded without a timer task. */
    uint32_t now = (uint32_t)get_timer_ticks();
    for (int i = 0; i < DNS_CACHE_SIZE; i++) {
        if (dns_cache_entry_live(&dns_cache[i], now) &&
            strcmp(dns_cache[i].name, hostname) == 0) {
            if (dns_cache[i].negative) return -1;
            *result = dns_cache[i].ip;
            return 0;
        }
    }

    /* Send query */
    int id = dns_query(hostname, DNS_TYPE_A);
    if (id < 0) return -1;

    /* Wait for response (simplified - would use async in real impl) */
    for (int i = 0; i < 100; i++) {
        now = (uint32_t)get_timer_ticks();
        for (int j = 0; j < DNS_CACHE_SIZE; j++) {
            if (dns_cache_entry_live(&dns_cache[j], now) &&
                strcmp(dns_cache[j].name, hostname) == 0) {
                if (dns_cache[j].negative) return -1;
                *result = dns_cache[j].ip;
                return 0;
            }
        }
        /* DNS is invoked synchronously by the HTTP/NetSurf path.  Without
         * pumping the RX path here, the QEMU reply cannot reach
         * dns_handle_response() until after this loop has already timed out. */
        net_poll();
        /* Do not consume an entire timeslice while waiting for UDP DNS. The
         * transport is progressing asynchronously in the NIC, so yield to
         * GUI/input and other runnable workers between polls. */
        thread_yield();
    }

    return -1;  // Timeout
}
